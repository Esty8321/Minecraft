import React from 'react';
import VoxelGrid from './components/VoxelGrid.tsx';

function App() {
  return <VoxelGrid />;
}

export default App;